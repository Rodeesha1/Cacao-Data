conversion_dict = {'Akesson Estate': 'Madagascar', 'Akesson P.': 'Madagascar', 'Ambolikapiky P.': 'Madagascar', 'Ambolikapkly P.': 'Madagascar', 'Amazon Basin Blend': 'Brazil', 'Arriba Nacional': 'Ecuador', 'Bahia Black': 'Brazil', 'Chanchamayo': 'Peru', 'Chuao': 'Venezuela', 'Crayfish Bay Estate': 'Grenada', 'Dom. Rep': 'Dominican Republic', 'Dom. Rep.': 'Dominican Republic', 'D.R.': 'Dominican Republic', 'DR': 'Dominican Republic', 'D.R.)': 'Dominican Republic', 'Dominican Republicm': 'Dominican Republic', 'Ecu.': 'Ecuador', 'Ecuad.': 'Ecuador', 'El Ceibo Coop': 'Bolivia', 'Fazenda Sempre Firme P.': 'Brazil', 'Fazenda Sao Pedro': 'Brazil', 'Gre.': 'Grenada', 'Guat.': 'Guatemala', 'Haw.': 'Hawaii', 'Ivory Coast': 'Ivory Coast', 'Jam': 'Jamaica', 'Kolumbia': 'Colombia', 'Mad.': 'Madagascar', 'Mex': 'Mexico', 'Millot Plantation': 'Madagascar', 'Nacional': 'Ecuador', 'Nic.': 'Nicaragua', 'Oko Caribe': 'Dominican Republic', 'Perou': 'Peru', 'Porcelana': 'Venezuela', 'Trinitario': 'Trinidad', 'U.K.': 'UK', 'U.S.A.': 'USA', 'Ven': 'Venezuela', 'Ven.': 'Venezuela', 'Ven)': 'Venezuela', 'Venzuela': 'Venezuela', 'Winak Coop': 'Ecuador', 'Brasil': 'Brazil', "Cote D'Ivoire": 'Ivory Coast', 'Aprocampa Coop': 'Peru', 'Akosombo': 'Ghana', 'Kokoa Kamili Coop': 'Tanzania'}

Antigua": "Guatemala      "Curacao": "Curacao",   "Cuyuni": "Guyana",  "Czech Republic": "Czech Republic"  "Cacao Indio": "Puerto Rico",

country_mapping = {
    "Uwate", "Cypher","Comoros","Abinao","AFR": "Africa",
    
    "AMZ": "Amazon",

    "Argentina": "Argentina",

    "Austria": "Austria",

    "AUS": "Australia",
    
    "Callebaut","BEL": "Belgium",
    
    "Bolivian", "Beniamo", "Beni", "Baures", "Upper Rio Beni", "Wild Thing","Wild Harvest","Wild Beni","Wild Beniano","Wild Bolivia","Wild Bolivian", "Cotoca", "Coroma", "Cordillera", "Chuquisaca", "Charagua", "Chapare", "Alto Beni", "BOL": "Bolivia",
    
    "Belize South", "Chiquibul","Cayo","BLZ": "Belize",

       "Campesino W", "Cabosse", "C. Am.", "Brooklyn Blend", "Brazil Blend", "Blu", "Blend No. 1", "Blend No. 49", "Bayou Blend", "Venezuela; Barinos", "Venezuela And Ghana", "White Label","West Africa","W. F. Blend Prototype","W.F. Blend Prototype","Colombia, Ecuador","Chocoa","Centroamerica","Central Africa","Central America","Cee","Cecilia","Carribean","Cargill","Capuchin","Autumn","Aranama", "Africa Meets Latina", "Africa": "Blend",
    
    "Brasil", "Brazil Rio Doce", "Brazilian","Bahia", "Bahia Black", "Bahia Brazil", "Bahia Superior", "Varzea", "Vale Do Juliana","Vale Do Juliana E.", "Coocaa","Coocabo Coop","Conquista","Cocao","Ceara","Castanhal","Catongo","Capim Branco","Candido Godoi","Atsane","Atlantic Forest","Arawak", "Anselmo Paraiso Estate", "Amazon","Amazon Basin Blend","Amazon Rainforest","Amazonas","Amazonas Frucht","Amazonas W","Amazonia","Amazonian Highlands","BRA": "Brazil",
    
    "CAN": "Canada",
    
    "CHE": "Switzerland",

    "Baracoa": "Cuba",

    "Copiapó","Chili","Calbuco": "Chile",
    
    "CIV", "Cote D'Ivoire": "Ivory Coast",
    
    "CMR": "Cameroon",
    
    "Virunga", "Congo","Congo D.R.","COG": "Republic of the Congo",
    
     "Boyaca", "Umoho R.", "Coocatrans Coop","Compania","Clemencia","Cienaga","Choco","Chigorodó","CENCOIC Co-op","Cauca","Casanare","Casa Luker", "Cartagena", "Candelaria", "Campestre", "Calamar","Arhuacos","Arauca", "Agua Fria; Sucre Region", "COL": "Colombia",
    
     "Upala", "Upala W", "Cartago","Agrocriso Plantation", "CRI": "Costa Rica",

    "Chiatura": "Georgia",
    
    "DEU": "Germany",

    "Coulibistrie": "Dominica",
    
     "Yacao Region","Zorzal Reserva","Zorzal Reserva W","Cocotal","Cibao","Cibao Valley","DOM": "Dominican Republic",
    
    "Camino Verde", "Camino Verde P.", "Calceta Beans", "Cacao Nacional", "Cacao Nacional W.F.", "Balao", "Uranga", "Unocace", "Vinces", "Winak", "Winak Coop", "Coup de Grace","Cotopaxi","Chinchipe","Cayapas","Cangahua","Arriba","Arriba Nacional","Amina", "Alpaco", "Akata", "ECU": "Ecuador",

    "Vanua Levu": "Fiji",

    "Courville","Corsica","Cognac","FRA": "France",

    "Cayenne": "French Guiana",
    
    "Wales","GBR": "United Kingdom",
    
    "Cape Coast","Asante","Ankasa", "Akosombo", "Abocfa Coop", "GHA": "Ghana",

    "Camahogne", "Winward","Crayfish Bay Estate": "Grenada",
    
    "Cacao Verapaz", "Cahabon", "Cahabon Region","Chicacao","Chajul","Asochivite", "Alta Verapaz", "GTM": "Guatemala",
    
    "Wampusirpi","Wampusirpi Region","Xoco","Copán","Comunidad P","Comayagua","HND": "Honduras",
    
    "Voodoo", "Cap-Haitien","Acul-Du-Nord", "HTI": "Haiti",
    
    "Bali", "Bali (West)", "Balinese", "Central Sulawesi","IDN": "Indonesia",
    
    "Camp Co-op","IND": "India",
    
    "ITA": "Italy",

    "Blue Mountain", "Blue Mountain Region": "Jamaica",
    
    "JPN": "Japan",

    "Chania": "Kenya",
    
    "KOR": "South Korea",
    
    "Ceylon","LKA": "Sri Lanka",
    
    "Ampamakia 2005", "Ami-Ami-Ca", "Ambanja","Ambolikapiky","Ambolikapiky P.","Ambolikapkly P.","Akesson","Akesson Estate","Akesson P.","Akesson'S","Akesson'S E.","Akesson'S Estate","Akessons Estate","MDG": "Madagascar",
    
    "Xoconusco","Xocunusco","Coyoacán","Cocoyoc","Cholula","Cherán","Chiapas","Chiapas, Mexico","Cascabel","Almendra Blanca", "MEX": "Mexico",
    
    "Asajaya E","MYS": "Malaysia",

    "Burma", "Birmanie": "Myanmar"
    
    "Cacao Bisiesto", "Cacao Bisesto", "Barba", "Waslala","Corinto","Chontales","Chichigalpa","NIC": "Nicaragua",
    
    "Amsterdam", "NLD": "Netherlands",

    "Bocas Del Toro", "Colon","Coclé","Changuinola": "Panama",
    
     "Cacao Real", "Cacao Blanco", "Cacao Blanc", "Cacao Cusco","Bellavista Coop", "Bellavista Gran Pajeten", "Bambamarca", "Villa Andina", "Cusco", "Cusco,Peru", "Coya", "Copaya", "Coexca", "Chililique", "Chazuta", "Chequiará", "Chanchamayo", "Chachapoyas", "Canoveral","Camana","Cajamarca","Ayacucho","Apotequil","Aprocampa Coop","Apurimac","Andoa", "Acopagro", "PER": "Peru",
    
    "Consolacion","Calapo","Calay","Alea Estate +World", "PHL": "Philippines",
    
    "Chinika","PNG": "Papua New Guinea",
    
    "SLV": "El Salvador",
    
    "Uba Budo", "Vila Gracinda", "Agua Grande", "STP": "São Tomé and Príncipe",

    "Canaries Valley", "Canaries", "St. Lucia",: "Saint Lucia",

    "Cingapura": "Singapore",
    
    "TGO": "Togo",
    
    "Chaguanas","Antilles (Trin", "TTO": "Trinidad and Tobago",
    
    "TZA": "Tanzania",

    "Celik": "Turkey",
    
    "Bundibugyo", "Bundibugyo District", "UGA": "Uganda",

     "Big Island", "Wasatch","Waiahole","Waialua E.","Waialua Estate","Waialua Estate W","Carolina","American Style", "Agri Research C.", "Abstract S. W", "U.S.A.": "USA",
    
     "Bolivar", "Barinas", "Barlovento", "Urrutia", "Venzuela", "Ven", "Ven)", "Ven.", "Venez", "Venezuela": "Venezuela","Zulia","Zulia Prov.","Cuyagua","Coro","Cordero","Ciudad Bolívar","Cindad Bolivar","Choroni","Chuao","Cedeño","Caripe","Caripito","Carenero Superior","Caracas","Carenero","Canoabo","Campo", "Caicara","Caicara de Maturin","Aragua","Aragua Region","Araguani","Apamate","Amiari Meridena", "Acarigua", "VEN": "Venezuela",
    
    "Ben Tre", "VNM": "Vietnam",

    "Both Man", "Coup de Foudre","Conibah","Cocoa Village","Cocoa Of Excellence","Cocoa from Heaven","Chocolatera","Chaqwa","Canaan","Agri-Forestal Plantation": "Unknown"
}
